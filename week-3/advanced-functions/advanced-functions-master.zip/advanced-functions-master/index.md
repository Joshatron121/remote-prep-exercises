# Functional Programming

##### Advanced Functions

[Advanced Functions](advancedFunctions.html)

[Advanced Functions Exercises](advancedFunctionsExercises.html)

##### Scope

[Scope Test Runner](scope/SpecRunner.html)
[Test Runner Instructions](scope/scopeExercises.html)

##### Closure

[Closure Exercises](closureExercises.html)

#####Re-implementing Underscore
[Re-implementing Underscore](implementingUnderscore.html)

